#pragma once

#include <cassert>
#include <memory>
#include <memory_resource>
#include <vector>


namespace Bat
{
#define ASSERT(cond, msg)assert(cond && msg)

	class chunk_memory_resource :public std::pmr::memory_resource {
	public:
		chunk_memory_resource() = default;
		chunk_memory_resource( std::size_t chunk_size )
			:
			m_chunk_size( chunk_size )
		{}

		chunk_memory_resource( chunk_memory_resource const& ) = delete;
		chunk_memory_resource( chunk_memory_resource && rhs ) = default;

		chunk_memory_resource& operator=( chunk_memory_resource const& ) = delete;
		chunk_memory_resource& operator=( chunk_memory_resource && rhs )noexcept = default;


	private:
		void* do_allocate( size_t amount, size_t alignment )override {
			auto& chunk = m_chunks.emplace_back( std::make_unique<char[]>( m_chunk_size ) );

			return chunk.get();
		}
		void do_deallocate( void* ptr, size_t amount, size_t alignment )override {
			auto is_same =
				[&]( const std::unique_ptr<char[]>& chunk ) {return chunk.get() == ptr; };

			auto it = std::find_if( m_chunks.begin(), m_chunks.end(), is_same );

			if( it != m_chunks.end() ) 
				m_chunks.erase( it );
			else 
				throw std::runtime_error( "chunk not found" );
		}
		bool do_is_equal( const memory_resource& rhs ) const noexcept override {
			return this == std::addressof( rhs );
		}

	private:
		std::vector<std::unique_ptr<char[]>> m_chunks;
		std::size_t m_chunk_size = {};
		std::size_t m_byte_offset = {};
	};

	template<typename T, std::size_t chunk_max = std::size_t{ 4096 } >
	class chunk_allocator {
	public:
		using value_type = T;
		using size_type = std::size_t;
		using difference_type = std::ptrdiff_t;

	public:
		chunk_allocator() = default;
		chunk_allocator( chunk_memory_resource* presource )
			:
			m_resource( presource )
		{}
		T* allocate() {
			m_resource->allocate( obj_size, obj_align );
		}
		template<typename...Args>
		T construct( T* pobj, Args&&... args ) {
			auto* result = new ( pobj ) T{ std::forward<Args>( args )... };

		}
	private:
		static constexpr auto obj_size = sizeof( T );
		static constexpr auto obj_align = alignof( T );
		chunk_memory_resource* m_resource = nullptr;
		std::size_t m_position = {};

	};
}