#pragma once

#include "rect_traits.h"
#include "vector_traits.h"
#include <cstdlib>
#include <memory>
#include <stdexcept>
#include <vector>

template<
	std::size_t allowed_objects_per_node,
	typename RectTraits,
	typename VecTraits,
	typename Object>
	class qtree {
	public:
		using rect_traits = RectTraits;
		using vec_traits = VecTraits;

		using rect_type = typename rect_traits::rect_type;
		using vec_type = typename vec_traits::vector_type;

		using object_type = Object;
		using iterator = typename std::vector<object_type>::iterator;
		using const_iterator = typename std::vector<object_type>::const_iterator;
	public:
		class data {
		public:
			data( rect_type const& bounds, object_type* pObj )noexcept
				:
				m_bounds( bounds ),
				m_pObject( pObj )
			{}
			rect_type const& bounds()const noexcept {
				return m_bounds;
			}
			object_type const& object()const noexcept {
				return *m_pObject;
			}
			object_type& object()noexcept {
				return *m_pObject;
			}
		private:
			rect_type m_bounds = {};
			object_type* m_pObject = nullptr;
		};

		class node {
		public:
			node( rect_type const& bounds_ )
				:
				m_bounds( bounds_ )
			{
				m_data.reserve( max_objects );
			}

			std::vector<data>& elements()noexcept {
				return m_data;
			}
			std::vector<data> const& elements()const noexcept {
				return m_data;
			}
			rect_type const& bounds()const noexcept {
				return m_bounds;
			}
		private:
			void query( rect_type const& bounds, std::vector<object_type*>& contained ) {
				if( rect_traits::intersects( m_bounds, bounds ) ) {
					for( auto& child : m_pChildren ) {
						if( child )
							child->query( bounds, contained );
					}
					for( auto& element : m_data ) {
						if( rect_traits::intersects( element.bounds(), bounds ) )
							contained.push_back( &element.object() );
					}
				}
			}
			rect_type get_quadrant( int index )const noexcept {
				const auto left = rect_traits::left( m_bounds );
				const auto top = rect_traits::top( m_bounds );
				const auto right = rect_traits::right( m_bounds );
				const auto bottom = rect_traits::bottom( m_bounds );
				const auto center =
					rect_traits::template center<vec_traits>( m_bounds );

				switch( index ) {
					case 0: // left top
						return rect_traits::construct( left, top, center.x, center.y );
					case 1: // right top
						return rect_traits::construct( center.x, top, right, center.y );
					case 2: // left bottom 
						return rect_traits::construct( left, center.y, center.x, bottom );
					case 3: // right bottom
						return rect_traits::construct( center.x, center.y, right, bottom );
				}

				// TODO: assert( index >= 0 && index < 4 && "Index out of range");
				return rect_type{};
			}

			bool add_to_child( data const& data_ ) {
				for( int index = 0; auto & child : m_pChildren ) {
					auto quadrant = get_quadrant( index++ );

					if( !rect_traits::contains( quadrant, data_.bounds() ) )
						continue;

					if( !child )
						child = std::make_unique<node>( quadrant );

					if( child->m_data.size() >= max_objects )
						return false;

					child->add_object( data_ );
					return true;
				}

				return false;
			}
			void add_object( data const& data_ ) {
				if( !add_to_child( data_ ) ) {
					m_data.push_back( data_ );
				}
				/*if( m_data.size() < max_objects ) {
					m_data.push_back( data_ );
				}
				else {
					m_data.push_back( data_ );
					auto temp = std::move( m_data );
					for( auto& element : temp ) {
						if( !add_to_child( element ) ) {
							m_data.push_back( element );
						}
					}
				}*/
			}
		private:
			friend class qtree;
			static constexpr std::size_t max_objects = allowed_objects_per_node;
			std::unique_ptr<node> m_pChildren[ 4 ] = {};
			std::vector<data> m_data;
			rect_type m_bounds;
		};

		qtree( rect_type const& bounds_ )
			:
			root( bounds_ )
		{}


		void push( object_type const& object ) {
			objects.push_back( object );
		}
		void push( object_type&& object ) {
			objects.push_back( std::move( object ) );
		}

		template<typename...Args>
		object_type& emplace( Args&&... args ) {
			return objects.emplace_back( std::forward<Args>( args )... );
		}

		template<typename GetRectFn>
		void commit( GetRectFn get_rect ) {
			root = node( root.m_bounds );
			for( auto& object : objects ) {
				root.add_object( { get_rect( object ), &object } );
			}
		}

		void reserve( std::size_t count ) {
			if( count > objects.max_size() )
				throw std::invalid_argument( "max_size exceeded" );
			if( count > objects.size() )
				objects.reserve( count );
		}

		void clear()noexcept {
			root = node( root.m_bounds );
			objects.clear();
		}

		iterator begin()noexcept {
			return objects.begin();
		}
		iterator end()noexcept {
			return objects.end();
		}

		const_iterator begin()const noexcept {
			return objects.cbegin();
		}
		const_iterator end()const noexcept {
			return objects.cend();
		}

		std::vector<object_type*> query( rect_type const& bounds ) {
			std::vector<object_type*> objects;
			root.query( bounds, objects );
			return objects;
		}
	private:
		node root;
		std::vector<object_type> objects;
};
